// ═══ UNIVERSAL EDUCATION SYSTEM — Class 1-12 + College + Professional ═══
export interface EduSubject{id:string;name:string;icon:string;stream:string[];classRange:[number,number]}
export interface EduChapter{id:string;subjectId:string;name:string;classRange:[number,number];topics:string[];notes?:string[];formulas?:string[]}

export const boards=['CBSE','ICSE','State Board','IB','Cambridge','Custom'] as const;
export const streams=['Science','Commerce','Arts','General'] as const;
export const classes=Array.from({length:12},(_,i)=>i+1);
export const countries=['India','USA','UK','Australia','Canada','Other'] as const;

export const collegePrograms=[
  {id:'btech',name:'B.Tech / B.E.',icon:'⚙️',duration:4},{id:'bsc',name:'B.Sc.',icon:'🔬',duration:3},
  {id:'bcom',name:'B.Com.',icon:'📊',duration:3},{id:'bba',name:'BBA',icon:'💼',duration:3},
  {id:'ba',name:'B.A.',icon:'📚',duration:3},{id:'bca',name:'BCA',icon:'💻',duration:3},
  {id:'bed',name:'B.Ed.',icon:'🎓',duration:2},{id:'mbbs',name:'MBBS',icon:'🏥',duration:5},
  {id:'nursing',name:'Nursing',icon:'🩺',duration:4},{id:'law',name:'Law (LLB)',icon:'⚖️',duration:5},
  {id:'diploma',name:'Diploma',icon:'📜',duration:3},{id:'poly',name:'Polytechnic',icon:'🔧',duration:3},
  {id:'mtech',name:'M.Tech / M.E.',icon:'⚙️',duration:2},{id:'msc',name:'M.Sc.',icon:'🔬',duration:2},
  {id:'mba',name:'MBA',icon:'💼',duration:2},{id:'mca',name:'MCA',icon:'💻',duration:2},
  {id:'ma',name:'M.A.',icon:'📚',duration:2},{id:'phd',name:'Ph.D.',icon:'🎓',duration:5},
  {id:'custom',name:'Custom Program',icon:'📋',duration:4},
];

// ═══ SUBJECTS — FULL K-12 ═══
export const subjects:EduSubject[]=[
  // ── PRIMARY (1-5) ──
  {id:'eng',name:'English',icon:'📝',stream:['General','Science','Commerce','Arts'],classRange:[1,12]},
  {id:'hindi',name:'Hindi',icon:'🇮🇳',stream:['General','Science','Commerce','Arts'],classRange:[1,12]},
  {id:'math',name:'Mathematics',icon:'🔢',stream:['General','Science','Commerce'],classRange:[1,12]},
  {id:'evs',name:'Environmental Studies',icon:'🌿',stream:['General'],classRange:[1,5]},
  {id:'art',name:'Art & Craft',icon:'🎨',stream:['General'],classRange:[1,8]},
  {id:'gk',name:'General Knowledge',icon:'🌍',stream:['General'],classRange:[1,8]},
  {id:'moral',name:'Moral Science',icon:'🕊️',stream:['General'],classRange:[1,8]},
  {id:'comp_p',name:'Computer Basics',icon:'🖥️',stream:['General'],classRange:[1,5]},
  // ── MIDDLE (6-8) ──
  {id:'sci',name:'Science',icon:'🔬',stream:['General'],classRange:[6,10]},
  {id:'sst',name:'Social Science',icon:'📖',stream:['General'],classRange:[6,10]},
  {id:'comp_m',name:'Computer Applications',icon:'💻',stream:['General'],classRange:[6,8]},
  {id:'skt',name:'Sanskrit',icon:'📜',stream:['General'],classRange:[6,10]},
  // ── SECONDARY (9-10) ──
  {id:'it',name:'Information Technology',icon:'💻',stream:['General'],classRange:[9,10]},
  // ── SENIOR SECONDARY (11-12) — SCIENCE ──
  {id:'phy',name:'Physics',icon:'⚛️',stream:['Science'],classRange:[11,12]},
  {id:'chem',name:'Chemistry',icon:'🧪',stream:['Science'],classRange:[11,12]},
  {id:'bio',name:'Biology',icon:'🧬',stream:['Science'],classRange:[11,12]},
  {id:'cs',name:'Computer Science',icon:'💻',stream:['Science'],classRange:[11,12]},
  {id:'ip',name:'Informatics Practices',icon:'📊',stream:['Science'],classRange:[11,12]},
  {id:'pe',name:'Physical Education',icon:'🏃',stream:['Science','Commerce','Arts'],classRange:[11,12]},
  {id:'appmath',name:'Applied Mathematics',icon:'📐',stream:['Commerce'],classRange:[11,12]},
  // ── SENIOR SECONDARY — COMMERCE ──
  {id:'acc',name:'Accountancy',icon:'📊',stream:['Commerce'],classRange:[11,12]},
  {id:'bst',name:'Business Studies',icon:'💼',stream:['Commerce'],classRange:[11,12]},
  {id:'eco',name:'Economics',icon:'📈',stream:['Commerce','Arts'],classRange:[11,12]},
  {id:'entre',name:'Entrepreneurship',icon:'🚀',stream:['Commerce'],classRange:[11,12]},
  // ── SENIOR SECONDARY — ARTS ──
  {id:'hist',name:'History',icon:'🏛️',stream:['Arts'],classRange:[11,12]},
  {id:'geo',name:'Geography',icon:'🌍',stream:['Arts'],classRange:[11,12]},
  {id:'pol',name:'Political Science',icon:'⚖️',stream:['Arts'],classRange:[11,12]},
  {id:'soc',name:'Sociology',icon:'👥',stream:['Arts'],classRange:[11,12]},
  {id:'psy',name:'Psychology',icon:'🧠',stream:['Arts'],classRange:[11,12]},
  {id:'phil',name:'Philosophy',icon:'💭',stream:['Arts'],classRange:[11,12]},
  // ── COMPETITIVE ──
  {id:'reasoning',name:'Logical Reasoning',icon:'🧩',stream:['General','Science','Commerce','Arts'],classRange:[1,12]},
  {id:'aptitude',name:'Aptitude',icon:'📊',stream:['General','Science','Commerce','Arts'],classRange:[6,12]},
  {id:'current',name:'Current Affairs',icon:'📰',stream:['General','Arts'],classRange:[6,12]},
];

// ═══ CHAPTERS — COMPREHENSIVE CLASS-WISE ═══
export const chapters:EduChapter[]=[
  // ── MATH: PRIMARY ──
  {id:'m1_cnt',subjectId:'math',name:'Counting & Numbers',classRange:[1,2],topics:['Counting 1-100','Place Value','Comparing Numbers','Before/After','Skip Counting'],notes:['Count objects in groups of 10','Place value: Ones, Tens, Hundreds']},
  {id:'m1_add',subjectId:'math',name:'Addition & Subtraction',classRange:[1,3],topics:['Single Digit','Double Digit','Word Problems','Carrying','Borrowing'],notes:['Addition: combining groups','Subtraction: taking away']},
  {id:'m1_mul',subjectId:'math',name:'Multiplication & Division',classRange:[2,5],topics:['Times Tables','Long Multiplication','Division','Remainders','Word Problems'],notes:['Multiplication is repeated addition','Division is sharing equally']},
  {id:'m1_frac',subjectId:'math',name:'Fractions & Decimals',classRange:[3,7],topics:['What are Fractions','Types of Fractions','Operations','Decimals','Conversion'],notes:['Fraction = Part/Whole','Numerator/Denominator']},
  {id:'m1_shape',subjectId:'math',name:'Shapes & Patterns',classRange:[1,5],topics:['2D Shapes','3D Shapes','Symmetry','Patterns','Tessellations'],notes:['Circle, Square, Triangle, Rectangle','Cube, Sphere, Cylinder, Cone']},
  {id:'m1_meas',subjectId:'math',name:'Measurement',classRange:[1,5],topics:['Length','Weight','Capacity','Time','Money'],notes:['cm, m, km for length','g, kg for weight','mL, L for capacity']},
  {id:'m1_data',subjectId:'math',name:'Data Handling',classRange:[3,5],topics:['Pictographs','Bar Graphs','Tally Marks','Tables'],notes:['Collect, organize, represent data']},
  // ── MATH: MIDDLE ──
  {id:'m_num',subjectId:'math',name:'Number Systems',classRange:[6,10],topics:['Natural Numbers','Whole Numbers','Integers','Rational','Irrational','Real Numbers','HCF/LCM'],notes:['N⊂W⊂Z⊂Q⊂R','HCF: largest common factor','LCM: smallest common multiple'],formulas:['HCF×LCM=Product of numbers']},
  {id:'m_alg',subjectId:'math',name:'Algebra',classRange:[6,12],topics:['Variables','Expressions','Linear Equations','Quadratic Equations','Polynomials','Factorization','Sequences & Series'],notes:['Variable: unknown value represented by letter','Equation: expression with = sign'],formulas:['ax²+bx+c=0 → x=(-b±√(b²-4ac))/2a','Sum of AP: S=n/2(2a+(n-1)d)']},
  {id:'m_geo',subjectId:'math',name:'Geometry',classRange:[1,12],topics:['Lines & Angles','Triangles','Circles','Quadrilaterals','Coordinate Geometry','Constructions','Congruence','Similarity'],notes:['Sum of angles in triangle=180°','Exterior angle=sum of remote interior angles'],formulas:['Area triangle=½bh','Area circle=πr²','Circumference=2πr']},
  {id:'m_mensur',subjectId:'math',name:'Mensuration',classRange:[6,10],topics:['Perimeter','Area','Volume','Surface Area','Curved Surface Area'],notes:['Perimeter: total boundary length','Volume: space occupied'],formulas:['Rectangle area=l×b','Cube volume=a³','Cylinder volume=πr²h','Sphere volume=4/3πr³']},
  {id:'m_ratio',subjectId:'math',name:'Ratio & Proportion',classRange:[6,8],topics:['Ratios','Proportions','Unitary Method','Percentages','Profit & Loss','Simple Interest'],notes:['Ratio compares two quantities','Percentage=Part/Whole×100'],formulas:['SI=PRT/100','Profit%=(Profit/CP)×100']},
  {id:'m_trig',subjectId:'math',name:'Trigonometry',classRange:[9,12],topics:['Trigonometric Ratios','Identities','Heights & Distances','Inverse Trigonometry','Applications'],notes:['SOH-CAH-TOA','sin²θ+cos²θ=1'],formulas:['sin30°=1/2','cos60°=1/2','tan45°=1','sin²θ+cos²θ=1']},
  {id:'m_calc',subjectId:'math',name:'Calculus',classRange:[11,12],topics:['Limits','Continuity','Derivatives','Integration','Differential Equations','Applications'],notes:['Derivative=rate of change','Integral=area under curve'],formulas:['d/dx(xⁿ)=nxⁿ⁻¹','∫xⁿdx=xⁿ⁺¹/(n+1)+C','d/dx(sinx)=cosx']},
  {id:'m_stat',subjectId:'math',name:'Statistics & Probability',classRange:[6,12],topics:['Mean','Median','Mode','Probability','Distributions','Standard Deviation'],notes:['Mean=Sum/Count','Probability=Favorable/Total'],formulas:['Mean=Σx/n','Variance=Σ(x-μ)²/n','P(A∪B)=P(A)+P(B)-P(A∩B)']},
  {id:'m_sets',subjectId:'math',name:'Sets & Functions',classRange:[11,12],topics:['Set Theory','Relations','Functions','Domain & Range','Composition','Inverse'],notes:['Set: well-defined collection','Function: each input has exactly one output'],formulas:['n(A∪B)=n(A)+n(B)-n(A∩B)']},
  {id:'m_mat',subjectId:'math',name:'Matrices & Determinants',classRange:[12,12],topics:['Matrix Operations','Types','Transpose','Determinants','Inverse','Cramer\'s Rule'],formulas:['(AB)ᵀ=BᵀAᵀ','A⁻¹=adj(A)/|A|','|AB|=|A||B|']},
  {id:'m_vec',subjectId:'math',name:'Vectors & 3D Geometry',classRange:[12,12],topics:['Vector Operations','Dot Product','Cross Product','Direction Cosines','Lines','Planes'],formulas:['a⃗·b⃗=|a||b|cosθ','|a⃗×b⃗|=|a||b|sinθ']},
  {id:'m_lpp',subjectId:'math',name:'Linear Programming',classRange:[12,12],topics:['Formulation','Graphical Method','Corner Point Theorem','Feasible Region'],notes:['Optimal at corner point of feasible region']},
  // ── SCIENCE (6-10) ──
  {id:'s_food',subjectId:'sci',name:'Food & Nutrition',classRange:[6,7],topics:['Nutrients','Balanced Diet','Food Sources','Deficiency Diseases'],notes:['6 nutrients: carbs, protein, fat, vitamins, minerals, water']},
  {id:'s_matter',subjectId:'sci',name:'Matter & Materials',classRange:[6,9],topics:['States of Matter','Mixtures','Solutions','Elements','Compounds','Atoms','Molecules'],notes:['Solid/Liquid/Gas','Atom: smallest unit of element']},
  {id:'s_living',subjectId:'sci',name:'Living World',classRange:[6,8],topics:['Plants','Animals','Microorganisms','Cell','Body Systems','Classification'],notes:['Cell: basic unit of life','5 kingdoms of classification']},
  {id:'s_motion',subjectId:'sci',name:'Motion & Force',classRange:[7,10],topics:['Types of Motion','Speed','Velocity','Acceleration','Force','Friction','Pressure','Gravity'],notes:['Speed=Distance/Time','F=ma'],formulas:['v=u+at','s=ut+½at²','v²=u²+2as']},
  {id:'s_energy',subjectId:'sci',name:'Energy & Work',classRange:[7,10],topics:['Forms of Energy','Work','Power','Machines','Conservation'],notes:['Work=Force×Distance','Energy cannot be created or destroyed'],formulas:['W=F×d','P=W/t','KE=½mv²','PE=mgh']},
  {id:'s_light',subjectId:'sci',name:'Light & Sound',classRange:[6,10],topics:['Reflection','Refraction','Lens','Mirror','Sound Waves','Echo'],notes:['Law of reflection: angle i = angle r','Sound needs medium to travel'],formulas:['v=fλ','1/v+1/u=1/f','n=sini/sinr']},
  {id:'s_elec',subjectId:'sci',name:'Electricity & Magnetism',classRange:[7,10],topics:['Current','Circuit','Resistance','Ohm\'s Law','Magnets','Electromagnetic Effects'],notes:['Current=Charge/Time','V=IR'],formulas:['V=IR','P=VI','R=ρl/A']},
  {id:'s_chem',subjectId:'sci',name:'Chemical Reactions',classRange:[8,10],topics:['Types of Reactions','Acids Bases Salts','Metals Non-metals','Carbon Compounds','Periodic Table'],notes:['pH scale: 0-14, 7=neutral','Metals are lustrous, malleable, ductile']},
  {id:'s_life',subjectId:'sci',name:'Life Processes',classRange:[9,10],topics:['Nutrition','Respiration','Transport','Excretion','Control & Coordination','Reproduction'],notes:['Photosynthesis: 6CO₂+6H₂O→C₆H₁₂O₆+6O₂']},
  {id:'s_env',subjectId:'sci',name:'Environment',classRange:[6,10],topics:['Ecosystem','Biodiversity','Pollution','Conservation','Natural Resources','Ozone'],notes:['3Rs: Reduce, Reuse, Recycle','Food chain: producer→consumer']},
  // ── EVS (1-5) ──
  {id:'evs_family',subjectId:'evs',name:'My Family & Friends',classRange:[1,3],topics:['Family Members','Neighborhood','Helpers','Festivals','House'],notes:['Family types: nuclear, joint']},
  {id:'evs_plants',subjectId:'evs',name:'Plants & Animals',classRange:[1,5],topics:['Parts of Plants','Types of Animals','Food from Plants','Animal Habitats'],notes:['Plants need sun, water, air, soil']},
  {id:'evs_body',subjectId:'evs',name:'My Body',classRange:[1,3],topics:['Body Parts','Senses','Hygiene','Food Groups','Exercise'],notes:['5 senses: sight, hearing, smell, taste, touch']},
  {id:'evs_earth',subjectId:'evs',name:'Our Earth',classRange:[3,5],topics:['Water','Air','Soil','Weather','Seasons','Maps'],notes:['70% of Earth is water','3 types of soil: sandy, clayey, loamy']},
  {id:'evs_safety',subjectId:'evs',name:'Safety & Health',classRange:[1,5],topics:['Road Safety','First Aid','Clean Habits','Good Touch Bad Touch','Emergency Numbers'],notes:['Traffic lights: Red=Stop, Yellow=Wait, Green=Go']},
  // ── ENGLISH (1-12) ──
  {id:'e_alpha',subjectId:'eng',name:'Alphabet & Phonics',classRange:[1,2],topics:['Letters','Sounds','Blending','Sight Words','Simple Words']},
  {id:'e_read',subjectId:'eng',name:'Reading Comprehension',classRange:[1,12],topics:['Stories','Passages','Poems','Unseen Passages','Note Making','Summarizing'],notes:['Read twice: first for gist, second for detail']},
  {id:'e_write',subjectId:'eng',name:'Writing Skills',classRange:[3,12],topics:['Sentences','Paragraphs','Essays','Letters','Articles','Reports','Notices','Advertisements'],notes:['Follow format for formal writing','Use topic sentences']},
  {id:'e_gram',subjectId:'eng',name:'Grammar',classRange:[1,12],topics:['Nouns','Verbs','Adjectives','Adverbs','Tenses','Prepositions','Articles','Active-Passive','Direct-Indirect','Clauses','Modals','Subject-Verb Agreement'],notes:['12 tenses: 4 types × 3 times','Active→Passive: swap subject-object']},
  {id:'e_vocab',subjectId:'eng',name:'Vocabulary',classRange:[1,12],topics:['Synonyms','Antonyms','Idioms','Phrases','One Word Substitution','Homophones','Spelling']},
  {id:'e_lit',subjectId:'eng',name:'Literature',classRange:[6,12],topics:['Prose','Poetry','Drama','Novel','Short Stories','Character Analysis','Themes'],notes:['Literature reflects human experience']},
  // ── SOCIAL SCIENCE (6-10) ──
  {id:'ss_hist',subjectId:'sst',name:'History',classRange:[6,10],topics:['Ancient India','Medieval India','Modern India','World History','Freedom Movement','Nationalism'],notes:['IVC: 2600-1900 BCE','Independence: 15 Aug 1947']},
  {id:'ss_geo',subjectId:'sst',name:'Geography',classRange:[6,10],topics:['Earth','Maps','Climate','Resources','Agriculture','Industries','Population','Transport'],notes:['Latitude: horizontal lines','Longitude: vertical lines']},
  {id:'ss_civics',subjectId:'sst',name:'Civics',classRange:[6,10],topics:['Democracy','Constitution','Government','Rights','Judiciary','Local Government'],notes:['Fundamental Rights: Article 14-32','3 branches: Legislature, Executive, Judiciary']},
  {id:'ss_eco',subjectId:'sst',name:'Economics',classRange:[9,10],topics:['Development','Sectors','Money & Credit','Globalisation','Consumer Rights'],notes:['Primary: agriculture, Secondary: industry, Tertiary: services']},
  // ── PHYSICS (11-12) ──
  {id:'p_mech',subjectId:'phy',name:'Mechanics',classRange:[11,12],topics:['Kinematics','Laws of Motion','Work Energy Power','Gravitation','Rotational Motion','Oscillations'],formulas:['v=u+at','F=ma','W=Fd cosθ','KE=½mv²','T=2π√(l/g)']},
  {id:'p_thermo',subjectId:'phy',name:'Thermodynamics',classRange:[11,12],topics:['Heat','Temperature','Laws','Kinetic Theory','Specific Heat','Calorimetry'],formulas:['Q=mcΔT','PV=nRT','W=PΔV']},
  {id:'p_waves',subjectId:'phy',name:'Waves & Optics',classRange:[11,12],topics:['Wave Motion','Sound','Light','Interference','Diffraction','Polarization','Ray Optics'],formulas:['v=fλ','1/f=1/v-1/u','n=sini/sinr','β=λD/d']},
  {id:'p_elec',subjectId:'phy',name:'Electrostatics & Current',classRange:[11,12],topics:['Coulomb\'s Law','Electric Field','Potential','Capacitance','Ohm\'s Law','Kirchhoff\'s Laws'],formulas:['F=kq₁q₂/r²','V=IR','C=Q/V','P=VI']},
  {id:'p_mag',subjectId:'phy',name:'Magnetism & EMI',classRange:[12,12],topics:['Magnetic Field','Biot-Savart','Ampere\'s Law','Faraday\'s Law','AC Circuits','EM Waves'],formulas:['F=qvBsinθ','emf=-dΦ/dt','Z=√(R²+(XL-XC)²)']},
  {id:'p_modern',subjectId:'phy',name:'Modern Physics',classRange:[12,12],topics:['Photoelectric Effect','Bohr Model','Nuclei','Radioactivity','Semiconductors'],formulas:['E=hν','Eₙ=-13.6/n² eV','t½=0.693/λ']},
  // ── CHEMISTRY (11-12) ──
  {id:'c_struct',subjectId:'chem',name:'Structure of Atom',classRange:[11,12],topics:['Atomic Models','Quantum Numbers','Electron Configuration','Periodic Table'],formulas:['E=hν','λ=h/mv','Aufbau Principle']},
  {id:'c_bond',subjectId:'chem',name:'Chemical Bonding',classRange:[11,12],topics:['Ionic','Covalent','Metallic','VSEPR Theory','Hybridization','MO Theory'],notes:['Ionic: metal+nonmetal','Covalent: nonmetal+nonmetal']},
  {id:'c_states',subjectId:'chem',name:'States of Matter',classRange:[11,12],topics:['Gas Laws','Ideal Gas','Kinetic Theory','Liquids','Solids'],formulas:['PV=nRT','PV/T=const']},
  {id:'c_thermo',subjectId:'chem',name:'Thermodynamics',classRange:[11,12],topics:['Enthalpy','Entropy','Gibbs Energy','Hess\'s Law'],formulas:['ΔG=ΔH-TΔS','q=nCpΔT']},
  {id:'c_equil',subjectId:'chem',name:'Equilibrium',classRange:[11,12],topics:['Chemical Equilibrium','Le Chatelier','Ionic Equilibrium','pH','Buffer Solutions'],formulas:['Kc=[products]/[reactants]','pH=-log[H⁺]']},
  {id:'c_redox',subjectId:'chem',name:'Redox & Electrochemistry',classRange:[11,12],topics:['Oxidation Numbers','Balancing Redox','Galvanic Cells','Electrolysis','Nernst Equation'],formulas:['E°cell=E°cathode-E°anode','E=E°-(RT/nF)lnQ']},
  {id:'c_organic',subjectId:'chem',name:'Organic Chemistry',classRange:[11,12],topics:['IUPAC Naming','Isomerism','Hydrocarbons','Reactions','Functional Groups','Polymers','Biomolecules'],notes:['Alkanes CnH2n+2','Alkenes CnH2n','Alkynes CnH2n-2']},
  {id:'c_coord',subjectId:'chem',name:'Coordination Compounds',classRange:[12,12],topics:['Werner\'s Theory','Naming','Isomerism','CFT','Applications'],notes:['Coordination number: bonds to central atom']},
  // ── BIOLOGY (11-12) ──
  {id:'b_diversity',subjectId:'bio',name:'Diversity of Life',classRange:[11,12],topics:['Classification','Plant Kingdom','Animal Kingdom','Morphology','Anatomy'],notes:['5 kingdoms: Monera, Protista, Fungi, Plantae, Animalia']},
  {id:'b_cell',subjectId:'bio',name:'Cell Biology',classRange:[11,12],topics:['Cell Structure','Cell Cycle','Division','Biomolecules','Enzymes'],notes:['Cell: basic unit of life','Mitosis: 2 identical cells','Meiosis: 4 haploid cells']},
  {id:'b_plant',subjectId:'bio',name:'Plant Physiology',classRange:[11,12],topics:['Transport','Mineral Nutrition','Photosynthesis','Respiration','Growth'],formulas:['6CO₂+6H₂O→C₆H₁₂O₆+6O₂']},
  {id:'b_human',subjectId:'bio',name:'Human Physiology',classRange:[11,12],topics:['Digestion','Breathing','Circulation','Excretion','Locomotion','Neural Control','Hormones'],notes:['Heart: 4 chambers','Kidneys: filter blood']},
  {id:'b_reprod',subjectId:'bio',name:'Reproduction',classRange:[12,12],topics:['Sexual Reproduction in Plants','Human Reproduction','Reproductive Health'],notes:['Double fertilization unique to angiosperms']},
  {id:'b_genetics',subjectId:'bio',name:'Genetics & Evolution',classRange:[12,12],topics:['Mendel\'s Laws','Molecular Basis','DNA','Evolution','Human Genome'],notes:['Monohybrid 3:1','Dihybrid 9:3:3:1','DNA→RNA→Protein'],formulas:['Hardy-Weinberg: p²+2pq+q²=1']},
  {id:'b_biotech',subjectId:'bio',name:'Biotechnology & Ecology',classRange:[12,12],topics:['Recombinant DNA','PCR','Applications','Ecosystem','Biodiversity','Environment'],notes:['PCR amplifies DNA','10% energy transfer rule']},
  // ── COMPUTER SCIENCE (11-12) ──
  {id:'cs_python',subjectId:'cs',name:'Python Programming',classRange:[11,12],topics:['Data Types','Control Flow','Functions','Lists','Tuples','Dictionaries','File Handling','Recursion'],notes:['Mutable: list, dict, set','Immutable: int, str, tuple']},
  {id:'cs_ds',subjectId:'cs',name:'Data Structures',classRange:[12,12],topics:['Stack','Queue','Sorting','Searching','Linked Lists','Trees'],notes:['Stack: LIFO','Queue: FIFO','Binary Search: O(log n)']},
  {id:'cs_sql',subjectId:'cs',name:'Database & SQL',classRange:[12,12],topics:['RDBMS','SQL Commands','Joins','Aggregate Functions','Group By'],notes:['DDL: CREATE ALTER DROP','DML: INSERT UPDATE DELETE SELECT']},
  {id:'cs_net',subjectId:'cs',name:'Networking',classRange:[12,12],topics:['Types','Topologies','Protocols','Security','Devices','Internet'],notes:['TCP/IP: 4 layers','HTTP, FTP, SMTP']},
  // ── ACCOUNTANCY (11-12) ──
  {id:'acc_intro',subjectId:'acc',name:'Introduction to Accounting',classRange:[11,12],topics:['Accounting Concepts','Journal','Ledger','Trial Balance','Financial Statements'],notes:['Double entry: every debit has a credit','Assets=Liabilities+Capital']},
  {id:'acc_partner',subjectId:'acc',name:'Partnership Accounts',classRange:[12,12],topics:['Fundamentals','Goodwill','Admission','Retirement','Dissolution'],notes:['Goodwill: reputation value','New ratio=Old-Sacrificing']},
  {id:'acc_company',subjectId:'acc',name:'Company Accounts',classRange:[12,12],topics:['Share Capital','Debentures','Financial Statements','Analysis','Cash Flow'],notes:['Equity vs Preference shares','Cash flow: Operating, Investing, Financing']},
  // ── BUSINESS STUDIES (11-12) ──
  {id:'bst_nature',subjectId:'bst',name:'Business & Management',classRange:[11,12],topics:['Nature of Business','Forms','Management Principles','Planning','Organizing','Staffing','Directing','Controlling'],notes:['Fayol: 14 principles','Taylor: Scientific Management']},
  {id:'bst_finance',subjectId:'bst',name:'Business Finance & Marketing',classRange:[12,12],topics:['Financial Management','Financial Markets','Marketing Mix','Consumer Protection'],notes:['4Ps: Product, Price, Place, Promotion','SEBI regulates markets']},
  // ── ECONOMICS (11-12) ──
  {id:'eco_micro',subjectId:'eco',name:'Microeconomics',classRange:[11,12],topics:['Demand & Supply','Elasticity','Production','Cost','Revenue','Market Forms','Price Determination'],notes:['Law of demand: price↑→demand↓'],formulas:['Ed=(ΔQ/ΔP)×(P/Q)']},
  {id:'eco_macro',subjectId:'eco',name:'Macroeconomics',classRange:[12,12],topics:['National Income','Money & Banking','Government Budget','Balance of Payments','AD-AS'],notes:['GDP=C+I+G+(X-M)','Multiplier=1/(1-MPC)'],formulas:['GDP=C+I+G+NX','Fiscal Deficit=Total Exp-Total Receipts(excl. borrowing)']},
  // ── HISTORY (11-12) ──
  {id:'h_ancient',subjectId:'hist',name:'Ancient & Medieval',classRange:[11,12],topics:['Harappan Civilization','Vedic Period','Mauryan Empire','Gupta Empire','Medieval India','Mughal Empire','Bhakti-Sufi'],notes:['IVC: 2600-1900 BCE','Ashoka: non-violence']},
  {id:'h_modern',subjectId:'hist',name:'Modern India',classRange:[11,12],topics:['Colonial Rule','1857 Revolt','National Movement','Gandhi','Partition','Constitution'],notes:['1857: First War of Independence','Independence: 15 Aug 1947']},
  // ── PE (11-12) ──
  {id:'pe_plan',subjectId:'pe',name:'Planning & Tournament',classRange:[11,12],topics:['Knock-Out','League','Seeding','Fixtures','Intramurals'],notes:['Knock-out: N-1 matches','League: N(N-1)/2 matches']},
  {id:'pe_health',subjectId:'pe',name:'Health & Nutrition',classRange:[11,12],topics:['BMI','Nutrition','Yoga','Sports Injuries','RICE','Training Methods'],notes:['BMI=weight/height²','RICE: Rest, Ice, Compression, Elevation'],formulas:['BMI=kg/m²']},
  // ── REASONING ──
  {id:'r_verbal',subjectId:'reasoning',name:'Verbal Reasoning',classRange:[6,12],topics:['Analogies','Classification','Series','Coding-Decoding','Blood Relations','Direction Sense'],notes:['Look for patterns','Eliminate wrong options']},
  {id:'r_nonverbal',subjectId:'reasoning',name:'Non-Verbal Reasoning',classRange:[6,12],topics:['Figure Series','Mirror Images','Paper Cutting','Embedded Figures','Dice'],notes:['Rotate mentally','Count sides and shapes']},
  {id:'r_logical',subjectId:'reasoning',name:'Logical Reasoning',classRange:[8,12],topics:['Syllogisms','Statements','Assumptions','Conclusions','Arguments','Critical Thinking'],notes:['All A are B, All B are C → All A are C']},
];

export function getSubjectsForClass(cls:number,stream:string):EduSubject[]{
  return subjects.filter(s=>{
    if(cls>=s.classRange[0]&&cls<=s.classRange[1]){
      if(cls<=10)return s.stream.includes('General')||s.stream.includes(stream);
      return s.stream.includes(stream);
    }
    return false;
  });
}

export function getChaptersForSubject(subjectId:string,cls:number):EduChapter[]{
  return chapters.filter(c=>c.subjectId===subjectId&&cls>=c.classRange[0]&&cls<=c.classRange[1]);
}

export function getAllSubjects():EduSubject[]{return subjects;}
