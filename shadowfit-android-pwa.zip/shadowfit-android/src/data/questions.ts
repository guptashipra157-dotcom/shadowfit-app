// ═══ EXPANDED QUESTION BANK ═══
export interface Question {
  id: string; subject: string; chapter: string; topic: string;
  difficulty: 'easy'|'medium'|'hard'; classLevel: number;
  question: string; options: string[]; correct: number; explanation: string;
}

export const questionBank: Question[] = [
  // ── MATHEMATICS ──
  {id:'ma1',subject:'Mathematics',chapter:'Arithmetic',topic:'Fractions',difficulty:'easy',classLevel:5,question:'What is 1/2 + 1/4?',options:['1/2','3/4','2/4','1/4'],correct:1,explanation:'1/2 = 2/4, so 2/4 + 1/4 = 3/4'},
  {id:'ma2',subject:'Mathematics',chapter:'Arithmetic',topic:'Percentages',difficulty:'easy',classLevel:6,question:'What is 25% of 200?',options:['25','50','75','100'],correct:1,explanation:'25/100 × 200 = 50'},
  {id:'ma3',subject:'Mathematics',chapter:'Arithmetic',topic:'Decimals',difficulty:'easy',classLevel:5,question:'What is 0.5 + 0.25?',options:['0.30','0.75','1.0','0.55'],correct:1,explanation:'0.50 + 0.25 = 0.75'},
  {id:'ma4',subject:'Mathematics',chapter:'Algebra',topic:'Linear Equations',difficulty:'easy',classLevel:7,question:'Solve: x + 5 = 12',options:['5','6','7','8'],correct:2,explanation:'x = 12 - 5 = 7'},
  {id:'ma5',subject:'Mathematics',chapter:'Algebra',topic:'Linear Equations',difficulty:'medium',classLevel:8,question:'Solve: 3x - 7 = 14',options:['5','6','7','8'],correct:2,explanation:'3x = 21, x = 7'},
  {id:'ma6',subject:'Mathematics',chapter:'Algebra',topic:'Quadratic Equations',difficulty:'medium',classLevel:10,question:'Find roots of x² - 5x + 6 = 0',options:['1,6','2,3','3,4','-2,-3'],correct:1,explanation:'(x-2)(x-3) = 0, so x = 2 or x = 3'},
  {id:'ma7',subject:'Mathematics',chapter:'Algebra',topic:'Polynomials',difficulty:'medium',classLevel:9,question:'Degree of 3x⁴ + 2x² - 1?',options:['2','3','4','1'],correct:2,explanation:'Highest power of x is 4'},
  {id:'ma8',subject:'Mathematics',chapter:'Geometry',topic:'Triangles',difficulty:'easy',classLevel:7,question:'Sum of angles in a triangle?',options:['90°','180°','270°','360°'],correct:1,explanation:'Sum of interior angles of triangle = 180°'},
  {id:'ma9',subject:'Mathematics',chapter:'Geometry',topic:'Circles',difficulty:'medium',classLevel:9,question:'Area of circle with radius 7 cm?',options:['154 cm²','44 cm²','49 cm²','22 cm²'],correct:0,explanation:'A = πr² = 22/7 × 49 = 154 cm²'},
  {id:'ma10',subject:'Mathematics',chapter:'Trigonometry',topic:'Trigonometric Ratios',difficulty:'medium',classLevel:10,question:'sin 30° = ?',options:['1','1/2','√3/2','1/√2'],correct:1,explanation:'sin 30° = 1/2 (standard value)'},
  {id:'ma11',subject:'Mathematics',chapter:'Trigonometry',topic:'Identities',difficulty:'medium',classLevel:10,question:'sin²θ + cos²θ = ?',options:['0','1','2','sin2θ'],correct:1,explanation:'Fundamental Pythagorean identity'},
  {id:'ma12',subject:'Mathematics',chapter:'Calculus',topic:'Derivatives',difficulty:'medium',classLevel:11,question:'d/dx(x³) = ?',options:['x²','3x²','3x','x³'],correct:1,explanation:'Power rule: d/dx(xⁿ) = nxⁿ⁻¹, so 3x²'},
  {id:'ma13',subject:'Mathematics',chapter:'Calculus',topic:'Integration',difficulty:'hard',classLevel:12,question:'∫2x dx = ?',options:['x²+C','2x²+C','x+C','2+C'],correct:0,explanation:'∫2x dx = 2(x²/2) + C = x² + C'},
  {id:'ma14',subject:'Mathematics',chapter:'Statistics & Probability',topic:'Probability',difficulty:'easy',classLevel:8,question:'Probability of getting head in a coin toss?',options:['0','1/2','1','1/4'],correct:1,explanation:'P(head) = 1 favorable / 2 total = 1/2'},
  {id:'ma15',subject:'Mathematics',chapter:'Statistics & Probability',topic:'Mean Median Mode',difficulty:'medium',classLevel:9,question:'Mean of 2, 4, 6, 8, 10?',options:['4','5','6','8'],correct:2,explanation:'(2+4+6+8+10)/5 = 30/5 = 6'},
  {id:'ma16',subject:'Mathematics',chapter:'Sets & Functions',topic:'Set Theory',difficulty:'medium',classLevel:11,question:'If A={1,2,3} B={2,3,4}, A∩B = ?',options:['{1,4}','{2,3}','{1,2,3,4}','{4}'],correct:1,explanation:'Intersection contains common elements'},
  {id:'ma17',subject:'Mathematics',chapter:'Number Systems',topic:'Real Numbers',difficulty:'easy',classLevel:9,question:'√2 is?',options:['Rational','Irrational','Integer','Natural'],correct:1,explanation:'√2 cannot be expressed as p/q'},
  {id:'ma18',subject:'Mathematics',chapter:'Mensuration',topic:'Volume',difficulty:'medium',classLevel:8,question:'Volume of cube with side 5cm?',options:['25 cm³','125 cm³','100 cm³','75 cm³'],correct:1,explanation:'V = a³ = 5³ = 125 cm³'},

  // ── PHYSICS ──
  {id:'ph1',subject:'Physics',chapter:'Mechanics',topic:'Motion',difficulty:'easy',classLevel:9,question:'SI unit of velocity?',options:['m/s','km/h','m/s²','N'],correct:0,explanation:'Velocity = displacement/time, SI unit is m/s'},
  {id:'ph2',subject:'Physics',chapter:'Mechanics',topic:'Force',difficulty:'easy',classLevel:9,question:'F = ma is?',options:['Newton\'s 1st law','Newton\'s 2nd law','Newton\'s 3rd law','Law of gravitation'],correct:1,explanation:'Newton\'s 2nd law: Force = mass × acceleration'},
  {id:'ph3',subject:'Physics',chapter:'Mechanics',topic:'Work Energy Power',difficulty:'medium',classLevel:9,question:'SI unit of work?',options:['Watt','Newton','Joule','Pascal'],correct:2,explanation:'Work = Force × distance, SI unit is Joule (J)'},
  {id:'ph4',subject:'Physics',chapter:'Mechanics',topic:'Gravitation',difficulty:'medium',classLevel:9,question:'g on Earth\'s surface ≈?',options:['8.9 m/s²','9.8 m/s²','10.8 m/s²','6.67 m/s²'],correct:1,explanation:'Acceleration due to gravity ≈ 9.8 m/s²'},
  {id:'ph5',subject:'Physics',chapter:'Waves & Optics',topic:'Light',difficulty:'easy',classLevel:10,question:'Speed of light in vacuum?',options:['3×10⁶ m/s','3×10⁸ m/s','3×10¹⁰ m/s','3×10⁴ m/s'],correct:1,explanation:'c ≈ 3 × 10⁸ m/s'},
  {id:'ph6',subject:'Physics',chapter:'Waves & Optics',topic:'Reflection',difficulty:'easy',classLevel:10,question:'Angle of incidence = ?',options:['Angle of refraction','Angle of reflection','90°','0°'],correct:1,explanation:'Law of reflection: angle of incidence = angle of reflection'},
  {id:'ph7',subject:'Physics',chapter:'Electricity & Magnetism',topic:'Current',difficulty:'medium',classLevel:10,question:'V = IR is?',options:['Coulomb\'s law','Ohm\'s law','Faraday\'s law','Ampere\'s law'],correct:1,explanation:'Ohm\'s law: Voltage = Current × Resistance'},
  {id:'ph8',subject:'Physics',chapter:'Electricity & Magnetism',topic:'Resistance',difficulty:'medium',classLevel:10,question:'SI unit of resistance?',options:['Ampere','Volt','Ohm','Watt'],correct:2,explanation:'Resistance is measured in Ohms (Ω)'},
  {id:'ph9',subject:'Physics',chapter:'Thermodynamics',topic:'Heat',difficulty:'medium',classLevel:11,question:'SI unit of temperature?',options:['Celsius','Fahrenheit','Kelvin','Joule'],correct:2,explanation:'SI unit of temperature is Kelvin (K)'},
  {id:'ph10',subject:'Physics',chapter:'Modern Physics',topic:'Photoelectric Effect',difficulty:'hard',classLevel:12,question:'Photoelectric effect was explained by?',options:['Newton','Bohr','Einstein','Planck'],correct:2,explanation:'Einstein explained it in 1905 using quantum theory'},

  // ── CHEMISTRY ──
  {id:'ch1',subject:'Chemistry',chapter:'Atomic Structure',topic:'Atoms',difficulty:'easy',classLevel:9,question:'Nucleus contains?',options:['Electrons','Protons & Neutrons','Only Protons','Only Electrons'],correct:1,explanation:'Nucleus has protons (+) and neutrons (0)'},
  {id:'ch2',subject:'Chemistry',chapter:'Atomic Structure',topic:'Periodic Table',difficulty:'medium',classLevel:10,question:'Elements in Group 18 are called?',options:['Alkali metals','Halogens','Noble gases','Transition metals'],correct:2,explanation:'Group 18 = Noble/Inert gases (He, Ne, Ar...)'},
  {id:'ch3',subject:'Chemistry',chapter:'Chemical Reactions',topic:'Types of Reactions',difficulty:'easy',classLevel:10,question:'Rusting of iron is?',options:['Decomposition','Combination','Oxidation','Reduction'],correct:2,explanation:'Iron reacts with O₂ and moisture = oxidation'},
  {id:'ch4',subject:'Chemistry',chapter:'Chemical Reactions',topic:'Balancing Equations',difficulty:'medium',classLevel:10,question:'In a balanced equation, what is conserved?',options:['Volume','Color','Mass','Temperature'],correct:2,explanation:'Law of conservation of mass'},
  {id:'ch5',subject:'Chemistry',chapter:'Organic Chemistry',topic:'Hydrocarbons',difficulty:'medium',classLevel:11,question:'Methane formula?',options:['CH₃','CH₄','C₂H₆','C₂H₂'],correct:1,explanation:'Methane is CH₄, simplest alkane'},
  {id:'ch6',subject:'Chemistry',chapter:'Solutions',topic:'Acids & Bases',difficulty:'easy',classLevel:10,question:'pH of pure water?',options:['0','7','14','1'],correct:1,explanation:'Pure water is neutral with pH = 7'},
  {id:'ch7',subject:'Chemistry',chapter:'Atomic Structure',topic:'Electron Configuration',difficulty:'medium',classLevel:11,question:'Max electrons in 2nd shell?',options:['2','4','8','18'],correct:2,explanation:'Max electrons in nth shell = 2n², so 2(2²) = 8'},
  {id:'ch8',subject:'Chemistry',chapter:'Solutions',topic:'Concentration',difficulty:'medium',classLevel:12,question:'Molarity is expressed in?',options:['g/L','mol/L','mol/kg','g/mL'],correct:1,explanation:'Molarity = moles of solute / liters of solution'},

  // ── BIOLOGY ──
  {id:'bi1',subject:'Biology',chapter:'Cell Biology',topic:'Cell Structure',difficulty:'easy',classLevel:8,question:'Powerhouse of the cell?',options:['Nucleus','Ribosome','Mitochondria','Golgi body'],correct:2,explanation:'Mitochondria produce ATP (energy currency)'},
  {id:'bi2',subject:'Biology',chapter:'Cell Biology',topic:'Cell Division',difficulty:'medium',classLevel:10,question:'Mitosis results in?',options:['4 cells','2 identical cells','2 different cells','1 cell'],correct:1,explanation:'Mitosis = 1 cell → 2 identical daughter cells'},
  {id:'bi3',subject:'Biology',chapter:'Genetics',topic:'DNA',difficulty:'medium',classLevel:10,question:'DNA stands for?',options:['Deoxyribonucleic acid','Dinitro acid','Dynamic nucleic acid','Dual nitrogen acid'],correct:0,explanation:'DeoxyriboNucleic Acid'},
  {id:'bi4',subject:'Biology',chapter:'Genetics',topic:'Inheritance',difficulty:'medium',classLevel:10,question:'Father of genetics?',options:['Darwin','Mendel','Lamarck','Watson'],correct:1,explanation:'Gregor Mendel discovered laws of inheritance'},
  {id:'bi5',subject:'Biology',chapter:'Ecology',topic:'Ecosystems',difficulty:'easy',classLevel:8,question:'Primary producers in ecosystem?',options:['Animals','Fungi','Green plants','Bacteria'],correct:2,explanation:'Green plants photosynthesize = primary producers'},
  {id:'bi6',subject:'Biology',chapter:'Human Physiology',topic:'Digestion',difficulty:'easy',classLevel:7,question:'Digestion starts in?',options:['Stomach','Small intestine','Mouth','Large intestine'],correct:2,explanation:'Saliva in mouth begins carbohydrate digestion'},
  {id:'bi7',subject:'Biology',chapter:'Human Physiology',topic:'Circulation',difficulty:'medium',classLevel:10,question:'Largest artery in human body?',options:['Pulmonary','Carotid','Aorta','Femoral'],correct:2,explanation:'Aorta carries oxygenated blood from heart'},
  {id:'bi8',subject:'Biology',chapter:'Human Physiology',topic:'Respiration',difficulty:'easy',classLevel:7,question:'Gas we breathe in?',options:['CO₂','O₂','N₂','H₂'],correct:1,explanation:'We inhale oxygen (O₂) for cellular respiration'},

  // ── COMPUTER SCIENCE ──
  {id:'cs1',subject:'Computer Science',chapter:'Programming',topic:'Python',difficulty:'easy',classLevel:9,question:'print("Hello") outputs?',options:['Hello','print(Hello)','Error','"Hello"'],correct:0,explanation:'print() outputs the string without quotes'},
  {id:'cs2',subject:'Computer Science',chapter:'Programming',topic:'Data Structures',difficulty:'medium',classLevel:11,question:'LIFO structure?',options:['Queue','Stack','Array','Tree'],correct:1,explanation:'Stack = Last In First Out'},
  {id:'cs3',subject:'Computer Science',chapter:'Computer Fundamentals',topic:'Hardware',difficulty:'easy',classLevel:6,question:'Brain of computer?',options:['RAM','Hard Disk','CPU','Monitor'],correct:2,explanation:'CPU (Central Processing Unit) processes everything'},
  {id:'cs4',subject:'Computer Science',chapter:'Databases',topic:'SQL',difficulty:'medium',classLevel:12,question:'SELECT * FROM students means?',options:['Delete all','Show all columns','Update all','Insert all'],correct:1,explanation:'SELECT * retrieves all columns from table'},
  {id:'cs5',subject:'Computer Science',chapter:'Programming',topic:'Algorithms',difficulty:'medium',classLevel:11,question:'Binary search time complexity?',options:['O(n)','O(n²)','O(log n)','O(1)'],correct:2,explanation:'Binary search halves search space each step'},

  // ── ECONOMICS ──
  {id:'ec1',subject:'Economics',chapter:'Microeconomics',topic:'Demand & Supply',difficulty:'medium',classLevel:11,question:'Law of demand states?',options:['Price↑ Demand↑','Price↑ Demand↓','Price= Demand=','No relation'],correct:1,explanation:'As price increases, quantity demanded decreases'},
  {id:'ec2',subject:'Economics',chapter:'Macroeconomics',topic:'National Income',difficulty:'medium',classLevel:12,question:'GDP stands for?',options:['Gross Daily Product','Gross Domestic Product','General Domestic Price','Growth Development Plan'],correct:1,explanation:'Gross Domestic Product = total value of goods produced'},

  // ── GENERAL KNOWLEDGE ──
  {id:'gk1',subject:'General Knowledge',chapter:'Science',topic:'Space',difficulty:'easy',classLevel:5,question:'Closest planet to Sun?',options:['Venus','Earth','Mercury','Mars'],correct:2,explanation:'Mercury orbits closest to the Sun'},
  {id:'gk2',subject:'General Knowledge',chapter:'History',topic:'World History',difficulty:'easy',classLevel:6,question:'Who discovered America?',options:['Magellan','Columbus','Vasco da Gama','Cook'],correct:1,explanation:'Christopher Columbus in 1492'},
  {id:'gk3',subject:'General Knowledge',chapter:'Geography',topic:'World',difficulty:'easy',classLevel:5,question:'Largest ocean?',options:['Atlantic','Indian','Arctic','Pacific'],correct:3,explanation:'Pacific Ocean is the largest'},
  {id:'gk4',subject:'General Knowledge',chapter:'Science',topic:'Human Body',difficulty:'easy',classLevel:4,question:'How many bones in adult body?',options:['106','206','306','256'],correct:1,explanation:'Adult human has 206 bones'},
  {id:'gk5',subject:'General Knowledge',chapter:'Arts',topic:'Culture',difficulty:'easy',classLevel:5,question:'Mona Lisa painted by?',options:['Michelangelo','Da Vinci','Raphael','Picasso'],correct:1,explanation:'Leonardo da Vinci, c. 1503-1519'},

  // ── REASONING ──
  {id:'re1',subject:'Reasoning',chapter:'Logical',topic:'Syllogisms',difficulty:'easy',classLevel:8,question:'If A>B, B>C, then?',options:['A<C','A=C','A>C','Cannot say'],correct:2,explanation:'Transitive: A>B>C ∴ A>C'},
  {id:'re2',subject:'Reasoning',chapter:'Numerical',topic:'Series',difficulty:'medium',classLevel:8,question:'Next: 2, 6, 12, 20, ?',options:['28','30','32','24'],correct:1,explanation:'Differences: 4,6,8,10 → 20+10=30'},
  {id:'re3',subject:'Reasoning',chapter:'Logical',topic:'Patterns',difficulty:'easy',classLevel:7,question:'Odd one out: 2,3,5,9,7',options:['2','3','9','7'],correct:2,explanation:'9 is not prime; others are prime numbers'},

  // ── FINANCE ──
  {id:'fi1',subject:'Finance',chapter:'Basics',topic:'Interest',difficulty:'easy',classLevel:8,question:'Simple Interest formula?',options:['P×R×T/100','P(1+R)^T','P×R/T','P+R+T'],correct:0,explanation:'SI = Principal × Rate × Time / 100'},
  {id:'fi2',subject:'Finance',chapter:'Basics',topic:'Interest',difficulty:'medium',classLevel:10,question:'CI formula?',options:['PRT/100','P(1+R/100)^T','P×R^T','P+RT'],correct:1,explanation:'Compound Interest: A = P(1 + R/100)^T'},
  {id:'fi3',subject:'Finance',chapter:'Basics',topic:'Budgeting',difficulty:'easy',classLevel:9,question:'50/30/20 rule: 50% goes to?',options:['Wants','Savings','Needs','Investment'],correct:2,explanation:'50% needs, 30% wants, 20% savings'},
];

export function getQuestions(filters: {subject?: string; chapter?: string; difficulty?: string; classLevel?: number; count?: number}): Question[] {
  let qs = [...questionBank];
  if (filters.subject) qs = qs.filter(q => q.subject === filters.subject);
  if (filters.chapter) qs = qs.filter(q => q.chapter === filters.chapter);
  if (filters.difficulty) qs = qs.filter(q => q.difficulty === filters.difficulty);
  if (filters.classLevel) { const cl = filters.classLevel; qs = qs.filter(q => q.classLevel <= cl); }
  qs.sort(() => Math.random() - 0.5);
  return qs.slice(0, filters.count || 10);
}
