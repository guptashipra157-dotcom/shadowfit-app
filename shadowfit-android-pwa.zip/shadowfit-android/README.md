# ⬡ SHADOWFIT: HUNTER SYSTEM
### Gamified Life OS — Android PWA

---

## 🚀 Deploy & Install (Free, No PC)

### Option A — Netlify (Easiest, 5 mins)

1. Go to **github.com** → Sign Up (free)
2. Create a new repo → Upload all these files
3. Go to **netlify.com** → "Add new site" → "Import from Git"
4. Connect your GitHub repo
5. Build settings auto-detected ✓
6. Click **Deploy** → Wait ~2 mins
7. Open the link in Chrome on your phone
8. Chrome shows **"Add to Home Screen"** banner → Tap **INSTALL**
9. App appears on your home screen like a real Android app ✓

### Option B — Netlify Drop (Instant, no GitHub)

> Requires building locally OR skip to GitHub approach

---

## ✅ What You Get

- 📱 Full-screen app (no browser bar)
- 📴 Works **completely offline**
- 💾 Data saved locally on your phone
- 🔔 Auto-install prompt on Android Chrome
- 🚀 Loads instantly after first visit
- 🔄 Auto-updates when you push new code

---

## 📁 Project Structure

```
shadowfit/
├── index.html          ← PWA-enhanced entry
├── public/
│   ├── manifest.json   ← Android install config
│   ├── sw.js           ← Offline service worker
│   ├── icon-192.png    ← Android icon
│   └── icon-512.png    ← Splash screen icon
├── src/
│   ├── App.tsx         ← Main app (15 modules)
│   ├── store.ts        ← Data & types
│   └── data/           ← Board exam, questions, etc.
├── netlify.toml        ← Auto-deploy config
└── .github/workflows/  ← GitHub Pages alternative
```

---

## 🎮 Modules

| Module | Icon | Description |
|--------|------|-------------|
| Fitness | 💪 | Workouts, calories, weight tracking |
| Study | 📚 | Sessions, notes, flashcards |
| Board Exam | 🎓 | CBSE/ICSE practice questions |
| College | 🏛️ | GPA, semesters, subjects |
| Exam | 📝 | Mock tests & quizzes |
| Flashcards | 🃏 | Spaced repetition |
| Code | 💻 | Coding session tracker |
| Math | 🔢 | Calculations & tools |
| Finance | 💰 | Income, expenses, goals |
| Tasks | 🎯 | To-do & habits |
| Media | 🖼️ | Notes & media |
| Knowledge | 📖 | Articles & learning |
| Stats | 📊 | Your progress dashboard |

---

*Built with React + Vite + TailwindCSS*
*Shadow Monarch rank requires Level 60 — get grinding* 🔥
